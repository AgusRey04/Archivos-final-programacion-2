from typing import Union

def agregar_titulo( )-> Union[bool,str]:
    titulo = input("Ingresar el nombre del título: ")
    horas = input("Ingresar la cantidad de horas del título: ")
    valido = horas.isnumeric() and int(horas) > 60
    return [valido, titulo] if valido else [valido, ' ']