import titulos

#Incializo una lista global con valores dummy
list_medicos = [{'nombre':"Juan", 'antiguedad': 16, 'matricula': "XLV12", 'titulos_reconocidos':['Pediatria','Clinica']},
                {'nombre':"Marta", 'antiguedad': 12, 'matricula': "XLI11", 'titulos_reconocidos':['Cardiologia','Clinica','Cirujano']}]

#variable global
menu = '''
--MENU--
1- Registrar médico
2- Agregar titulos a un médico
3- Mostrar resumen
4- Salir
'''

#variable global
sub_menu = '''
--MENU--
1- Agregar Titulo
2- Finalizar
'''

def validar_matricula(mat: str) -> bool:
    return all([c in 'XVIL1234567890' for c in mat])

def registrar_medico() -> None:
    nombre = input("Ingresar el nombre del médico: ")
    antiguedad = input("Ingresar la antiguedad en meses del médico: ")
    matricula = input("Ingresar la matrícula del del médico: (Carácteres permitidos: XVIL 0123456789) ")
    if validar_matricula(matricula):
        list_medicos.append({'nombre':nombre, 'antiguedad': antiguedad, 'matricula': matricula, 'titulos_reconocidos':[]})
        print("Se registró el médico existosamente ")
    else:
        print("No se puedo registrar el médico. Revise los datos ingresados.")

def agregar_titulos_medico() -> None:
    mat_buscar = input("Ingresar la matrícula del médico: ")
    medico_encontrado = False

    for medico in list_medicos:
        if medico['matricula'] == mat_buscar:
            medico_encontrado = medico
            break
    
    if medico_encontrado:
        print(f"Agregar titulos al medico: {medico_encontrado['nombre']}")
        while True:
            print(sub_menu)
            sub_opt = input("Seleccionar una opción de menú: ")
            if sub_opt == '1':
                valido, titulo = titulos.agregar_titulo()
                if valido: medico_encontrado['titulos_reconocidos'].append(titulo)
            elif sub_opt == '2':
                print("Finaliza la carga de títulos. ")
                break
            else:
                pass
    else:
        print("No se encontró el médico con la matrícula ingresada. ")
        agregar_titulos_medico()

def mostrar_resumen() -> None:
    print(f"Cantidad de médicos evaluados: {len(list_medicos)}", end='\n\n')
    list_medicos.sort(key=lambda x: len(x['titulos_reconocidos']), reverse=True)
    for medico in list_medicos:
        print(f"Médico: {medico['nombre']} - Matrícula: {medico['matricula']} - Antigüedad: {medico['antiguedad']} meses")
        print("Titulos: ", end='')
        [print(f"{t} - ", end='') for t in medico['titulos_reconocidos']]
        print(f"\n Cantidad de títulos reconocidos: {len(medico['titulos_reconocidos'])}", end="\n\n")

# app
while True:
    print(menu)
    opt = input("Seleccionar una opción de menú: ")
    if opt == '1':
        registrar_medico()
    elif opt == '2':
        agregar_titulos_medico()
    elif opt == '3':
        mostrar_resumen()
    elif opt == '4':
        print("Gracias por utilizar nuestro sistema. ")
        break
    else:
        print("Opción selecionada incorrecta. ")